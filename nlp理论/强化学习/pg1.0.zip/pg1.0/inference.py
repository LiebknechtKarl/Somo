import gym
from RL_brain import PolicyGradient

RENDER = True  # 在屏幕上显示模拟窗口会拖慢运行速度, 我们等计算机学得差不多了再显示模拟

env = gym.make('CartPole-v0')   # CartPole 这个模拟
env = env.unwrapped     # 取消限制
env.seed(1)     # 普通的 Policy gradient 方法, 使得回合的 variance 比较大, 所以我们选了一个好点的随机种子

RL = PolicyGradient(
    n_actions=env.action_space.n,                   # 可用 action     Discrete(2)代表有2个可用动作
    n_features=env.observation_space.shape[0],      #可用 observation
    learning_rate=0.02,
    reward_decay=0.99,                              # gamma    # discount factor    衰减度（未来奖励的衰减值）
    output_graph=True,                              # 输出 tensorboard 文件
)

if __name__ == "__main__":
    observation = env.reset()  # 将环境重置为初始状态并返回初始观测值。    observation重置
    while True:
        if RENDER:
            env.render()  # env.render()    #env.render()函数用于渲染出当前的智能体以及环境的状态。
        action = RL.choose_action(observation)  # 依据观测值（observation）选择action
        observation_, reward, done, info, _ = env.step(
            action)  # 返回值：observation（object）、reward（float）、是否终止done（boolean）、info（dict）
        observation = observation_
