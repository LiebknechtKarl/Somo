# import gym
# from RL_brain import PolicyGradient
#
# RENDER = True  # 在屏幕上显示模拟窗口会拖慢运行速度, 我们等计算机学得差不多了再显示模拟
#
# env = gym.make('CartPole-v0')   # CartPole 这个模拟
# env = env.unwrapped     # 取消限制
# env.seed(1)     # 普通的 Policy gradient 方法, 使得回合的 variance 比较大, 所以我们选了一个好点的随机种子
#
# RL = PolicyGradient(
#     n_actions=env.action_space.n,       # 可用 action     Discrete(2)代表有2个可用动作
#     n_features=env.observation_space.shape[0],      #可用observation
#     learning_rate=0.02,
#     reward_decay=0.99,   # gamma    # discount factor    衰减度（未来奖励的衰减值）
#     output_graph=True,    # 输出 tensorboard 文件
# )
#
# # acc = sess.run(accuracy, feed_dict={x: mnist.test.images, y: mnist.test.labels, keep_prob: 1.0})
# # print("Test_accuracy=" + str(acc))
#
# if __name__ == "__main__":
#     observation = env.reset()  # 将环境重置为初始状态并返回初始观测值。    observation重置
#     while True:
#         if RENDER: env.render()  # env.render()    #env.render()函数用于渲染出当前的智能体以及环境的状态。
#         action = RL.choose_action(observation)  # 依据观测值（observation）选择action
#         observation_, reward, done, info, _ = env.step(
#             action)  # 返回值：observation（object）、reward（float）、是否终止done（boolean）、info（dict）
#         observation = observation_


import matplotlib.pyplot as plt
import numpy as np
# from numpy import *

import gym
from RL_brain import PolicyGradient
import tensorflow.compat.v1 as tf       #替换原代码

RENDER = True  # 在屏幕上显示模拟窗口会拖慢运行速度, 我们等计算机学得差不多了再显示模拟

env = gym.make('CartPole-v0')   # CartPole 这个模拟
env = env.unwrapped     # 取消限制
env.seed(1)     # 普通的 Policy gradient 方法, 使得回合的 variance 比较大, 所以我们选了一个好点的随机种子


model_save_path = './model/'
model_name = 'model'

class PolicyGradient:
    def __init__(
            self,
            n_actions,
            n_features,
            learning_rate=0.01,
            reward_decay=0.95,
            output_graph=False,
    ):
        self.n_actions = n_actions
        self.n_features = n_features
        self.lr = learning_rate     # 学习率
        self.gamma = reward_decay   # reward 递减率


        self.ep_obs, self.ep_as, self.ep_rs = [], [], []    # 这是我们存储 回合信息的 list

        self._build_net()   # 建立 policy 神经网络

        self.sess = tf.Session()

        if output_graph:    # 是否输出 tensorboard 文件
            # $ tensorboard --logdir=logs
            # http://0.0.0.0:6006/
            # tf.train.SummaryWriter soon be deprecated, use following
            tf.summary.FileWriter("logs/", self.sess.graph)

        self.sess.run(tf.global_variables_initializer())

    def _build_net(self):
        # 利用占位符定义我们所需的神经网络的输入。
        # tf.placeholder()就是代表占位符，这里的None代表无论输入有多少都可以，因为输入只有一个特征，所以这里是1。
        with tf.name_scope('inputs'):
            tf.disable_eager_execution()  # 此行为后期添加改动
            self.tf_obs = tf.placeholder(tf.float32, [None, self.n_features], name="observations")  # 观测值
            self.tf_acts = tf.placeholder(tf.int32, [None, ], name="actions_num")  # 行为
            self.tf_vt = tf.placeholder(tf.float32, [None, ], name="actions_value")  # 行为奖励

        # 输入观测值，输出十个神经元
        layer = tf.layers.dense(
            inputs=self.tf_obs,  # 输入是观测值
            units=10,  # 输出个数，十个神经元
            activation=tf.nn.tanh,  # tanh activation   激励函数
            kernel_initializer=tf.random_normal_initializer(mean=0, stddev=0.3),
            bias_initializer=tf.constant_initializer(0.1),
            name='fc1'
        )
        # fc2   输出所有行为（action)的值
        # 输入十个神经元layer   输出动作个数组参数
        all_act = tf.layers.dense(
            inputs=layer,  # 输入是之前的layer
            units=self.n_actions,  # 输出是动作
            activation=None,
            kernel_initializer=tf.random_normal_initializer(mean=0, stddev=0.3),
            bias_initializer=tf.constant_initializer(0.1),
            name='fc2'
        )

        # ##################################################
        # saver = tf.train.Saver()
        # with tf.compat.v1.Session() as sess:
        #     init_op = tf.compat.v1.global_variables_initializer()
        #     sess.run(init_op)
        #     ckpt = tf.compat.v1.train.get_checkpoint_state(model_save_path)
        #     # 载入模型，不需要提供模型的名字，会通过 checkpoint 文件定位到最新保存的模型
        #     if ckpt and ckpt.model_checkpoint_path:
        #         saver.restore(sess, ckpt.model_checkpoint_path)
        #     # print("load success")
        # ####################################################

        self.all_act_prob = tf.nn.softmax(all_act, name='act_prob')  # use softmax to convert to probability



    def choose_action(self, observation):  # 选择动作

        ##################################################
        saver = tf.train.Saver()
        with tf.compat.v1.Session() as sess:
            init_op = tf.compat.v1.global_variables_initializer()
            sess.run(init_op)
            ckpt = tf.compat.v1.train.get_checkpoint_state(model_save_path)
            # 载入模型，不需要提供模型的名字，会通过 checkpoint 文件定位到最新保存的模型
            if ckpt and ckpt.model_checkpoint_path:
                saver.restore(sess, ckpt.model_checkpoint_path)
            # print("load success")
        ####################################################



        ###softmax处理  输出每一个action的值转化为概率
        ###self.all_act_prob = tf.nn.softmax(all_act, name='act_prob')  # use softmax to convert to probability
        prob_weights = self.sess.run(self.all_act_prob, feed_dict={
            self.tf_obs: observation[np.newaxis, :]})  # 依据当前observation输出每个action的概率，传给 prob_weights
        # print('prob_weights即执行两动作的概率为',prob_weights)
        # # prob_weights即执行两动作的概率为[[0.5076556 0.4923444]]
        action = np.random.choice(range(prob_weights.shape[1]),
                                  p=prob_weights.ravel())  # select action w.r.t the actions prob     根据概率值随机选取动作
        return action

#####
RL = PolicyGradient(
    n_actions=env.action_space.n,       # 可用 action     Discrete(2)代表有2个可用动作
    n_features=env.observation_space.shape[0],      #可用observation
    learning_rate=0.02,
    reward_decay=0.99,   # gamma    # discount factor    衰减度（未来奖励的衰减值）
    output_graph=True,    # 输出 tensorboard 文件
)
##################################################
saver = tf.train.Saver()
with tf.compat.v1.Session() as sess:
    init_op = tf.compat.v1.global_variables_initializer()
    sess.run(init_op)
    ckpt = tf.compat.v1.train.get_checkpoint_state(model_save_path)
    # RL = tf.compat.v1.train.get_checkpoint_state(model_save_path)

    # 载入模型，不需要提供模型的名字，会通过 checkpoint 文件定位到最新保存的模型
    if ckpt and ckpt.model_checkpoint_path:
        saver.restore(sess, ckpt.model_checkpoint_path)
    # if RL and RL.model_checkpoint_path:
    #     saver.restore(sess, RL.model_checkpoint_path)
    # print("load success")
####################################################
# acc = sess.run(accuracy, feed_dict={x: mnist.test.images, y: mnist.test.labels, keep_prob: 1.0})
# print("Test_accuracy=" + str(acc))

if __name__ == "__main__":

    global_r=[]
    for i_episode in range(10):
        # 回合更新，而不是单步更新
        sum_r=0
        observation = env.reset()  # 将环境重置为初始状态并返回初始观测值。    observation重置
        while True:
            if RENDER: env.render()  # env.render()    #env.render()函数用于渲染出当前的智能体以及环境的状态。
            action = RL.choose_action(observation)  # 依据观测值（observation）选择action
            observation_, reward, done, info, _ = env.step(
                action)  # 返回值：observation（object）、reward（float）、是否终止done（boolean）、info（dict）
            observation = observation_

            sum_r = sum_r + reward

            if done :
                print(i_episode,'\t', sum_r)
                break

        global_r.append(sum_r)
    print('平均值',np.mean(global_r))
