"""
Policy Gradient, Reinforcement Learning.

The cart pole example

View more on my tutorial page: https://morvanzhou.github.io/tutorials/

Using:
Tensorflow: 1.0
gym: 0.8.0
"""
import gym
from RL_brain import PolicyGradient
import matplotlib.pyplot as plt

RENDER = False                         # 在屏幕上显示模拟窗口会拖慢运行速度, 我们等计算机学得差不多了再决定是否显示模拟
DISPLAY_REWARD_THRESHOLD = 10000           # 当 回合总 reward 大于 400 时显示模拟窗口

env = gym.make('CartPole-v0')            # CartPole 这个模拟
env = env.unwrapped                      # 取消限制
env.seed(1)                              # 普通的 Policy gradient 方法, 使得回合的 variance 比较大, 所以我们选了一个好点的随机种子

# print(env.action_space)                  # 显示可用action --> Discrete(2)     代表有2个可用动作
# print(env.action_space.n)                # --> 2
# print(env.observation_space)             # 显示可用 state 的 observation
# print(env.observation_space.high)        # observation 最高值 [4.8000002e+00 3.4028235e+38 4.1887903e-01 3.4028235e+38]
# print(env.observation_space.low)         # observation 最低值 [-4.8000002e+00 -3.4028235e+38 -4.1887903e-01 -3.4028235e+38]

# 定义
RL = PolicyGradient(
    n_actions=env.action_space.n,                   # 可用 action     Discrete(2)代表有2个可用动作
    n_features=env.observation_space.shape[0],      #可用 observation
    learning_rate=0.02,
    reward_decay=0.99,                              # gamma    # discount factor    衰减度（未来奖励的衰减值）
    output_graph=True,                              # 输出 tensorboard 文件
)

for i_episode in range(100000):                     # 回合(episode)更新，而不是单步更新
    observation = env.reset()                       # 将环境重置为初始状态并返回初始观测值 -- observation重置

    while True:
        if RENDER:
            env.render()                            # env.render()函数用于渲染出当前的智能体以及环境的状态。

        action = RL.choose_action(observation)      # 依据观测值（observation）选择action
        # 返回值：observation（object）、reward（float）、是否终止done（boolean）、info（dict）
        observation_, reward, done, info, _ = env.step(action)

        # RL.store_transition(observation, action, reward)           # 存储这一回合的 transition
        RL.store_transition(observation, action, reward, i_episode)  # 存储这一回合的 transition

        if done:                                                     # 若回合结束
            ep_rs_sum = sum(RL.ep_rs)                                # 对一回合存储的 reward求和

            if 'running_reward' not in globals():                    # running_reward 是否创建
                running_reward = ep_rs_sum
            else:
                running_reward = running_reward * 0.99 + ep_rs_sum * 0.01       #迭代running_reward

            if running_reward > DISPLAY_REWARD_THRESHOLD: RENDER = True         # 判断是否显示模拟 400回合
            print("episode:", i_episode, "  reward:", int(running_reward))

            vt = RL.learn() # 回合结束，开始学习, 输出 vt,

            '''
            if i_episode == 0:
                plt.plot(vt)    # plot 这个回合的 vt
                plt.xlabel('episode steps')
                plt.ylabel('normalized state-action value')
                plt.show()
            '''
            break

        observation = observation_