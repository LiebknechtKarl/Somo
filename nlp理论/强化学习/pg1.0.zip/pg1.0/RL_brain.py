"""
This part of code is the reinforcement learning brain, which is a brain of the agent.
All decisions are made in here.

Policy Gradient, Reinforcement Learning.

View more on my tutorial page: https://morvanzhou.github.io/tutorials/

Using:
Tensorflow: 1.0
gym: 0.8.0
"""

import numpy as np
# import tensorflow as tf
import tensorflow.compat.v1 as tf       # 新版本的tf改了名称，需要此变动
# 一个约定俗称的声明，
# 不然会报错 --> The Session graph is empty.  Add operations to the graph before calling run().
# tf.disable_eager_execution()  # 加在这儿 回报错，使得模型训练的reward下降，得放在 build_net 中
import os

np.random.seed(1)
tf.set_random_seed(1)

class PolicyGradient:
    def __init__(
            self,
            n_actions,
            n_features,
            learning_rate=0.01,
            reward_decay=0.95,
            output_graph=False,
            pretrained_model = True
    ):
        self.n_actions = n_actions
        self.n_features = n_features
        self.lr = learning_rate                             # 学习率
        self.gamma = reward_decay                           # reward 递减率

        self.ep_obs, self.ep_as, self.ep_rs = [], [], []    # 这是我们存储 回合信息的 list

        self._build_net()                                   # 建立 policy 神经网络

        self.sess = tf.Session()

        if output_graph:
            # $ tensorboard --logdir=logs
            # http://0.0.0.0:6006/
            # tf.train.SummaryWriter soon be deprecated, use following
            tf.summary.FileWriter("logs/", self.sess.graph)

        self.sess.run(tf.global_variables_initializer())

        if pretrained_model:
            new_saver = tf.train.import_meta_graph('./models/mymodel.meta')
            new_saver.restore(self.sess, tf.train.latest_checkpoint('./models'))


    def _build_net(self):
        # 利用占位符定义我们所需的神经网络的输入。
        # tf.placeholder()就是代表占位符，这里的None代表无论输入有多少都可以，因为输入只有一个特征，所以这里是1。
        with tf.name_scope('inputs'):
            tf.disable_eager_execution()
            self.tf_obs = tf.placeholder(tf.float32, [None, self.n_features], name="observations")      #观测值
            self.tf_acts = tf.placeholder(tf.int32, [None, ], name="actions_num")                       #行为
            self.tf_vt = tf.placeholder(tf.float32, [None, ], name="actions_value")                     #行为奖励

        '''
        tf.layers.dense(input, units=k)会在内部自动生成一个权矩阵：kernel 和偏移项：bias，
        例如：对于尺寸为[m, n]的二维张量input， tf.layers.dense()会生成：
        尺寸为[n, k]的权矩阵：kernel，和尺寸为[m, k] 的偏移项：bias。
        内部的计算过程为y = input * kernel + bias，输出值y的维度为[m, k]。
        '''

        # tf.layers.dense：全连接层 fc1
        layer = tf.layers.dense(
            inputs=self.tf_obs,            # 输入: 观测值
            units=10,                      # 输出: 十个神经元
            activation=tf.nn.tanh,         # tanh activation   激活函数
            kernel_initializer=tf.random_normal_initializer(mean=0, stddev=0.3),    # 初始化权重参数
            bias_initializer=tf.constant_initializer(0.1),                          # 初始化偏置参数
            name='fc1'
        )
        # fc2   输出所有行为（action)的值
        # 输入十个神经元layer   输出动作个数组参数
        all_act = tf.layers.dense(
            inputs=layer,                             # 输入是之前的layer，10个神经元
            units=self.n_actions,                     # 输出是动作action， 2
            activation=None,
            kernel_initializer=tf.random_normal_initializer(mean=0, stddev=0.3),
            bias_initializer=tf.constant_initializer(0.1),
            name='fc2'
        )

        self.all_act_prob = tf.nn.softmax(all_act, name='act_prob')  # use softmax to convert to probability

        with tf.name_scope('loss'):
            '''
            最大化 总体 reward (log_p * R) <==> 最小化 -(log_p * R)。 是因为 tf 的功能里只有最小化 loss
            传入的logits为神经网络输出层的输出，shape为[batch_size，num_classes]，
            传入的label为一个一维的vector，长度等于batch_size，每一个值的取值区间必须是[0，num_classes)，
            其实每一个值就是代表了batch中对应样本的类别。
       
            all_act输出所有行为（action)的值
            print('all_act是',all_act)
            
            neg_log_prob = tf.nn.sparse_softmax_cross_entropy_with_logits(logits=all_act, labels=self.tf_acts)
            下面的方式是一样的:
            neg_log_prob = tf.reduce_sum(-tf.log(self.all_act_prob) * tf.one_hot(self.tf_acts, self.n_actions), axis=1)
            '''

            # self.all_act_prob 所有行为概率
            # tf.reduce_sum()作用是按一定方式计算张量中元素之和，注意‘-’
            neg_log_prob = tf.reduce_sum(-tf.log(self.all_act_prob) * tf.one_hot(self.tf_acts, self.n_actions), axis=1)
            # (tf_vt = 本reward + 衰减的未来reward) 引导参数的梯度下降
            loss = tf.reduce_mean(neg_log_prob * self.tf_vt)  # reward guided loss， self.tf_vt是每一步的奖励， neg_log_prob每一步的概率

        with tf.name_scope('train'):
            self.train_op = tf.train.AdamOptimizer(self.lr).minimize(loss)

    '''
    def choose_action(self, observation):
        # softmax处理，输出每一个action的值转化为概率
        # self.all_act_prob = tf.nn.softmax(all_act, name='act_prob')  # use softmax to convert to probability
        prob_weights = self.sess.run(self.all_act_prob, feed_dict={self.tf_obs: observation[np.newaxis, :]})      # 依据当前observation输出每个action的概率，传给 prob_weights

        # print('prob_weights即执行两动作的概率为',prob_weights)
        # prob_weights即执行两动作的概率为[[0.5076556 0.4923444]]
        action = np.random.choice(range(prob_weights.shape[1]), p=prob_weights.ravel())  # select action w.r.t the actions prob     根据概率值随机选取动作
        return action
    '''


    def choose_action(self, observation):
        # pretrained_model:预训练模型的路径
        # softmax处理，输出每一个action的值转化为概率
        # self.all_act_prob = tf.nn.softmax(all_act, name='act_prob')  # use softmax to convert to probability


        prob_weights = self.sess.run(self.all_act_prob,
                                     feed_dict={
                                         self.tf_obs: observation[np.newaxis, :]})  # 依据当前observation输出每个action的概率，传给 prob_weights

        # print('prob_weights即执行两动作的概率为',prob_weights)
        # prob_weights即执行两动作的概率为[[0.5076556 0.4923444]]
        action = np.random.choice(range(prob_weights.shape[1]),
                                  p=prob_weights.ravel())   # select action w.r.t the actions prob     根据概率值随机选取动作
        return action

    def store_transition(self, s, a, r, i):    # 存储, 加入回合数
        self.ep_obs.append(s)                  # observation,
        self.ep_as.append(a)                   # action,
        self.ep_rs.append(r)                   # reward
        self.ep_is = i                         # 用来固定每多少轮 输出模型

    def learn(self):
        # discount and normalize episode reward     学习更新参数
        discounted_ep_rs_norm = self._discount_and_norm_rewards()       #每一步进行打分结果

        # ==================================== 保存模型 =======================================
        model_save_path = './models/mymodel'
        model_name = 'models'
        saver = tf.train.Saver()

        # tup：输入的参数应该为一个元组，即(tuple)对象。有返回值，返回竖直堆叠后的数组。
        self.sess.run(self.train_op,
                      feed_dict={
                          self.tf_obs: np.vstack(self.ep_obs),             # shape=[None, n_obs]    观测值
                          self.tf_acts: np.array(self.ep_as),              # shape=[None, ]         动作
                          self.tf_vt: discounted_ep_rs_norm,               # shape=[None, ]         奖励 ?
                      })

        if self.ep_is % 70 == 0 :
            saver.save(self.sess, model_save_path)
            print('save success')
        '''
        if sum(self.ep_rs) > 200:
            saver.save(self.sess, model_save_path, global_step = 50, write_meta_graph=False)
            print('save success')
        '''
        # ===================================================================================

        self.ep_obs, self.ep_as, self.ep_rs = [], [], []    # empty episode data--(observation、action、reward)

        return discounted_ep_rs_norm

    def _discount_and_norm_rewards(self, discounted_ep_rs=None):       # 每一步进行打分

        discounted_ep_rs = np.zeros_like(self.ep_rs)
        running_add = 0
        for t in reversed(range(0, len(self.ep_rs))):       # reversed返回一个逆序序列的迭代器（用于遍历该逆序序列）
            running_add = running_add * self.gamma + self.ep_rs[t]
            discounted_ep_rs[t] = running_add   # 对每一步打分

        # print('discounted_ep_rs为',discounted_ep_rs)
        # discounted_ep_rs为 [10.46617457  9.5617925   8.64827525  7.72553056  6.79346521  5.85198506     4.90099501  3.940399    2.9701      1.99        1.        ]

        # 归一化
        discounted_ep_rs -= np.mean(discounted_ep_rs)
        discounted_ep_rs /= np.std(discounted_ep_rs)
        # print('最终discounted_ep_rs为', discounted_ep_rs)
        # 最终discounted_ep_rs为 [ 1.55734181  1.25521636  0.95003914  0.64177932  0.33040577  0.01588703  -0.30180867 -0.62271341 -0.94685962 -1.27428003 -1.60500771]

        return discounted_ep_rs


