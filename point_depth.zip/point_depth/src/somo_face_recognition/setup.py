from setuptools import setup

package_name = 'somo_face_recognition'

setup(
    name=package_name,
    version='0.0.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='somo',
    maintainer_email='464676762@qq.com',
    description='TODO: Package description',
    license='TODO: License declaration',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [

        # "somo_face_wdepth_scrfourpoint_without_gpu=somo_face_recognition.somo_face_wdepth_scrfourpoint_without_gpu:main",
        "somo_depth=somo_face_recognition.somo_depth:main",

        # "somo_depth0802=somo_face_recognition.somo_depth0802:main",
        # "somo_depth2=somo_face_recognition.somo_depth2:main",
        # "somo_depth3=somo_face_recognition.somo_depth3:main",





        ],
    },
)
