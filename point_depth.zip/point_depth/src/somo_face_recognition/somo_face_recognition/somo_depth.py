# import os
# os.environ['QT_QPA_PLATFORM'] = 'offscreen'
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
import numpy as np
import cv2
from somo_msgs.msg import FaceBoxes
from std_msgs.msg import String
#   接收/face_match   未压缩深度图/camera_up/aligned_depth_to_color/image_raw          发布  /face_match_result  包含关键点和深度值

class DepthToDepthValue(Node):
    def __init__(self):

        super().__init__('depth_to_depth_value')
        self.key = False
        self.keyid = False

        self.faceboxes_sub=self.create_subscription(FaceBoxes,"/face_match",self.union_callback,1)
        self.subscription = self.create_subscription(
            Image,
            '/camera_up/aligned_depth_to_color/image_raw',
            self.depth_callback,
            10,
            # self.default_callback_group
        )
        self.pub_face_match_result = self.create_publisher(FaceBoxes, "/face_match_result", 1)
        # TODO: 获取相机内参信息（畸变参数、焦距、主点等）


        self.face_id_sub = self.create_subscription(String, "/face_id", self.id_callback,1)


    def union_callback(self,msg) :          # 获取关键像素
        self.face_match_value = msg.result
        self.key = True
        self.face_match_header = msg.header
    
    def id_callback(self,msg) :
        self.keyid = True



    def depth_callback(self, msg):              #  深度图关键点的值
        print('1')
        if self.key and  self.keyid :
        # if  self.keyid :
            print(2)

            if True :
            # try :

                # 获取深度图像像素值数据
                depth_data = np.frombuffer(msg.data, dtype=np.uint16).reshape(msg.height, msg.width)

                # TODO: 使用相机内参和像素值数据转换为深度值
                # 例如，你可以使用逆深度投影算法将像素坐标转换为三维点，并计算深度值。

                # 这里只是一个简单的示例，将深度图像的像素值作为深度值输出
                depth_value = depth_data

                # 处理深度值数据
                # TODO: 可以对深度值数据进行处理，例如去除无效值、缩放等等

        
                
                self.face_match_value[0].depth1 = depth_value[self.face_match_value[0].y1][self.face_match_value[0].x1]*1.0
                # print(self.face_match_value[0].depth1)
                self.face_match_value[0].depth2 = depth_value[self.face_match_value[0].y2][self.face_match_value[0].x2]*1.0
                self.face_match_value[0].depth3 = depth_value[self.face_match_value[0].y3][self.face_match_value[0].x3]*1.0
                self.face_match_value[0].depth4 = depth_value[self.face_match_value[0].y4][self.face_match_value[0].x4]*1.0

                
                faceboxes = FaceBoxes()
                # faceboxes.header = self.face_match_header
                faceboxes.header = msg.header

                faceboxes.result = self.face_match_value
                self.pub_face_match_result.publish(faceboxes)
                print(faceboxes.result[0].depth1,faceboxes.result[0].depth2,faceboxes.result[0].depth3,faceboxes.result[0].depth4)

                self.key = False
                self.keyid = False


            # except :
            #     pass


def main(args=None):
    rclpy.init(args=args)
    depth_to_depth_value = DepthToDepthValue()
    rclpy.spin(depth_to_depth_value)
    depth_to_depth_value.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
