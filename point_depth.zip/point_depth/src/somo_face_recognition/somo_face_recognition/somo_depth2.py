# import os
# os.environ['QT_QPA_PLATFORM'] = 'offscreen'
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
import numpy as np
import cv2

class DepthToDepthValue(Node):
    def __init__(self):
        super().__init__('depth_to_depth_value')
        self.subscription = self.create_subscription(
            Image,
            '/camera_up/aligned_depth_to_color/image_raw',
            self.depth_callback,
            10
        )
        self.faceboxes_sub=self.create_subscription(FaceBoxes,"/face_match",self.union_callback,1)


        # TODO: 获取相机内参信息（畸变参数、焦距、主点等）

    def depth_callback(self, msg):
        # 获取深度图像像素值数据
        depth_data = np.frombuffer(msg.data, dtype=np.uint16).reshape(msg.height, msg.width)

        # TODO: 使用相机内参和像素值数据转换为深度值
        # 例如，你可以使用逆深度投影算法将像素坐标转换为三维点，并计算深度值。

        # 这里只是一个简单的示例，将深度图像的像素值作为深度值输出
        depth_value = depth_data

        # 处理深度值数据
        # TODO: 可以对深度值数据进行处理，例如去除无效值、缩放等等

        # 显示深度值数据
        # cv2.imshow("Depth Value", depth_value)
        # cv2.waitKey(1)
        print(depth_value.shape)

def main(args=None):
    rclpy.init(args=args)
    depth_to_depth_value = DepthToDepthValue()
    rclpy.spin(depth_to_depth_value)
    depth_to_depth_value.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
