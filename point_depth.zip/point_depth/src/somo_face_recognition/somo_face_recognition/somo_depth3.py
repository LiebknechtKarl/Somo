# import os
# os.environ['QT_QPA_PLATFORM'] = 'offscreen'
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
import numpy as np
import cv2
from somo_msgs.msg import FaceBoxes


class DepthToDepthValue(Node):
    def __init__(self):
        # 创建默认的回调组
        # self.default_callback_group = self.create_callback_group(rclpy.callback_groups.CallbackGroupType.DEFAULT)



        super().__init__('depth_to_depth_value')
        self.key = False


        # self.faceboxes_sub=self.create_subscription(FaceBoxes,"/face_match",10,qos_profile=rclpy.qos.QoSProfile(depth=10))
        self.faceboxes_sub=self.create_subscription(FaceBoxes,"/face_match",self.union_callback,1)

        self.subscription = self.create_subscription(
            Image,
            '/camera_up/aligned_depth_to_color/image_raw',
            self.depth_callback,
            10,
            # self.default_callback_group
        )

        self.pub_face_match_result = self.create_publisher(FaceBoxes, "/face_match_result", 1)




        # TODO: 获取相机内参信息（畸变参数、焦距、主点等）

    def union_callback(self,msg) :
        # print('face_match')
        # print('face_match',msg)
        self.face_match_value = msg.result
        # self.face_match_value = msg
        # print(self.face_match_value.result[0].depth1,'\n match')       # 0.0 


        self.key = True
        # faceboxes = FaceBoxes()
        # faceboxes.header = msg.header
        self.face_match_header = msg.header
        # print(faceboxes)


    def depth_callback(self, msg):
        if self.key :
            # while True :
            try :

                # 获取深度图像像素值数据
                depth_data = np.frombuffer(msg.data, dtype=np.uint16).reshape(msg.height, msg.width)

                # TODO: 使用相机内参和像素值数据转换为深度值
                # 例如，你可以使用逆深度投影算法将像素坐标转换为三维点，并计算深度值。

                # 这里只是一个简单的示例，将深度图像的像素值作为深度值输出
                depth_value = depth_data

                # 处理深度值数据
                # TODO: 可以对深度值数据进行处理，例如去除无效值、缩放等等

                # 显示深度值数据
                # cv2.imshow("Depth Value", depth_value)
                # cv2.waitKey(1)
                # print(depth_value.shape)
                # print(depth_value[1][1])

                # global topic_depth_data
                # topic_depth_data = depth_value

                # try :
                # if self.key :

                # print(self.face_match_value,'\n match')
                # print(type(self.face_match_value),'\n match')       # <class 'list'> 


                # print(self.face_match_value['depth1'],'\n match')
                # print(self.face_match_value[0],'\n match')          # somo_msgs.msg.FaceBox(det_score=0.9767926931381226, xmin=318.3437805175781, ymin=347.0526123046875, xmax=384.12030029296875, ymax=451.3771667480469, rec_score=0.11471552401781082, classname='unrecognizable', x1=351, y1=399, depth1=0.0, x2=356, y2=399, depth2=0.0, x3=346, y3=399, depth3=0.0, x4=351, y4=404, depth4=0.0) 
                # print(type(self.face_match_value[0]),'\n match')   # <class 'somo_msgs.msg._face_box.FaceBox'> 
                # print(self.face_match_value[0].depth1,'\n match')       # 0.0 
                # self.face_match_value[0].depth1 = 1.0
                # print(self.face_match_value[0].depth1)

                ######### MMMMMMMMMMMMMMMMMMMMMMMMMMMMM
                # self.face_match_value[0].depth1 = depth_value[self.face_match_value[0].x1][self.face_match_value[0].y1]/1000
                # # print(self.face_match_value[0].depth1)
                # self.face_match_value[0].depth2 = depth_value[self.face_match_value[0].x2][self.face_match_value[0].y2]/1000
                # self.face_match_value[0].depth3 = depth_value[self.face_match_value[0].x3][self.face_match_value[0].y3]/1000
                # self.face_match_value[0].depth4 = depth_value[self.face_match_value[0].x4][self.face_match_value[0].y4]/1000


                # self.face_match_value[0].depth1 = depth_value[self.face_match_value[0].y1][self.face_match_value[0].x1]/1000
                # # print(self.face_match_value[0].depth1)
                # self.face_match_value[0].depth2 = depth_value[self.face_match_value[0].y2][self.face_match_value[0].x2]/1000
                # self.face_match_value[0].depth3 = depth_value[self.face_match_value[0].y3][self.face_match_value[0].x3]/1000
                # self.face_match_value[0].depth4 = depth_value[self.face_match_value[0].y4][self.face_match_value[0].x4]/1000
                
                
                self.face_match_value[0].depth1 = depth_value[self.face_match_value[0].y1][self.face_match_value[0].x1]*1.0
                # print(self.face_match_value[0].depth1)
                self.face_match_value[0].depth2 = depth_value[self.face_match_value[0].y2][self.face_match_value[0].x2]*1.0
                self.face_match_value[0].depth3 = depth_value[self.face_match_value[0].y3][self.face_match_value[0].x3]*1.0
                self.face_match_value[0].depth4 = depth_value[self.face_match_value[0].y4][self.face_match_value[0].x4]*1.0
                # self.face_match_value[0].x1, self.face_match_value[0].y1= self.face_match_value[0].y1, self.face_match_value[0].x1
                # self.face_match_value[0].x2, self.face_match_value[0].y2= self.face_match_value[0].y2, self.face_match_value[0].x2
                # self.face_match_value[0].x3, self.face_match_value[0].y3= self.face_match_value[0].y3, self.face_match_value[0].x3
                # self.face_match_value[0].x4, self.face_match_value[0].y4= self.face_match_value[0].y4, self.face_match_value[0].x4
                
                
                
                
                ######### WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW





                # print(self.face_match_value[0],'\n match')       # 0.0 
                # self.aver_depth.publish(self.face_match_value )




                # faceboxes = FaceBoxes()
                # faceboxes.header = data.header
                # # 发布结果 & 画图,
                # res_out, image_rec_res = self.post_process(
                #     image_data, depth_data, dets, face_names, face_sims, crop_imgs)

                # faceboxes.result = res_out
                # # if self.pub_image == True:
                # #     faceboxes.image_data = self.bridge.cv2_to_imgmsg(
                # #         image_rec_res, 'bgr8')
                # #     print("pub the image in the faceboxes")
                # # # ----------------------------- 当非空列表时，发布facebox
                # if res_out != []:
                #     self.res_pub.publish(faceboxes)


                # if self.face_match_value[0].depth1  > 0.1 and self.face_match_value[0].depth2 > 0.1 and self.face_match_value[0].depth3 > 0.1 and self.face_match_value[0].depth4 > 0.1 and  self.face_match_value[0].depth1  < 10000  and  self.face_match_value[0].depth2  < 10000  and  self.face_match_value[0].depth3  < 10000  and  self.face_match_value[0].depth4  < 10000 :
                
                
                # print('1111111111111111')
                
                faceboxes = FaceBoxes()
                # faceboxes.header = self.face_match_header
                faceboxes.header = msg.header
                print('2222222222222222222222222')

                # print(faceboxes)
                faceboxes.result = self.face_match_value
                self.pub_face_match_result.publish(faceboxes)
                print(faceboxes.result[0].depth1,faceboxes.result[0].depth2,faceboxes.result[0].depth3,faceboxes.result[0].depth4)
                self.key = False

            except :
                pass











        # except :
        #     pass

        


def main(args=None):
    rclpy.init(args=args)
    depth_to_depth_value = DepthToDepthValue()
    rclpy.spin(depth_to_depth_value)
    depth_to_depth_value.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
