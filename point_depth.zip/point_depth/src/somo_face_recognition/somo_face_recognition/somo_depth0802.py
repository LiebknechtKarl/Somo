#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import rclpy
import cv2
from cv_bridge import CvBridge
from std_msgs.msg import String,Float32
from sensor_msgs.msg import Image, CompressedImage
from somo_msgs.msg import FaceBoxes

import numpy as np
import time
from rclpy.node import Node


class Compressed2Image(object):
    def __init__(self,w,h):
        self.width = w
        self.height = h
        self.min_depth = 0.10
        self.max_depth = 15.0
        self.is_disparity = False
        self.hue_value = []
        self.output_depth_data_array = np.zeros((self.height, self.width), dtype=np.uint16)
        self.depth_img_c = np.zeros((self.height, self.width), np.float32)
        self.d2d_convert_factor = 1.0
        self.cv_bridge = CvBridge()  


    def RGB2D(self, r, g, b):
        img_r, img_g, img_b = r, g, b
        img_d = np.zeros_like(img_r)
        r_1 = (img_r >= img_g) & (img_r >= img_b) & (img_g >= img_b)
        r_2 = (img_r >= img_g) & (img_r >= img_b) & (img_g < img_b)
        r_3 = (img_g >= img_r) & (img_g >= img_b)
        r_4 = (img_b >= img_g) & (img_b >= img_r)
        img_d[r_1] = img_g[r_1] - img_b[r_1]
        img_d[r_2] = img_g[r_2] - img_b[r_2] + 1529
        img_d[r_3] = img_b[r_3] - img_r[r_3] + 510
        img_d[r_4] = img_r[r_4] - img_g[r_4] + 1020
        return img_d


    def depth_colorization_recovery_fast(self, input_color_data_array):
        input_color_data_array = input_color_data_array.astype(np.uint16)
        is_disparity = self.is_disparity
        width = self.width
        height = self.height
        min_depth = self.min_depth
        max_depth = self.max_depth
        min_disparity = self.d2d_convert_factor / max_depth
        max_disparity = self.d2d_convert_factor / min_depth

        img_r, img_g, img_b = cv2.split(input_color_data_array)

        t0 = time.time()
        self.hue_value = self.RGB2D(img_r, img_g, img_b)

        t1 = time.time()
        self.hue_value = np.array(self.hue_value).reshape(1, -1)
        print("the_time0:", t1 - t0)

        output_depth_data_array = np.zeros((height, width), dtype=np.uint16)
        assert output_depth_data_array.shape == (height, width)
        output_depth_data_array = np.where((self.hue_value > 0) & (not is_disparity),
                                            (min_depth + (
                                                    max_depth - min_depth) * self.hue_value / 1529.0) / 0.001 + 0.5,
                                            self.d2d_convert_factor / (1529.0 / (1529.0 * min_disparity + (
                                                    max_disparity - min_disparity) * self.hue_value)) / 0.001 + 0.5)
        
        assert output_depth_data_array.shape == (1, height*width)
        
        return output_depth_data_array

    def forward(self, depth_img_c):

        input_color_data_array = depth_img_c

        print("原始的输入：",input_color_data_array.shape) # ------------------------------定位问题所在，此处的输入就有问题，shape(240, 424, 3)
        input_color_data_array = input_color_data_array.astype(np.uint16)
        is_disparity = self.is_disparity
        width = self.width
        height = self.height
        min_depth = self.min_depth
        max_depth = self.max_depth
        min_disparity = self.d2d_convert_factor / max_depth
        max_disparity = self.d2d_convert_factor / min_depth
        
        # self.depth_img_c = self.cv_bridge.compressed_imgmsg_to_cv2(depth_img_c)
        self.depth_img_c = self.cv_bridge.compressed_imgmsg_to_cv2(depth_img_c)

        # print("原始接收话题的shape：",self.depth_img_c.shape)
        print("depth_img_shape:",self.depth_img_c.shape)
        assert self.depth_img_c.shape == (self.height,self.width,3)
 
        self.depth_img_c = self.depth_colorization_recovery_fast(self.depth_img_c)
       
        self.depth_img_c = np.array(self.depth_img_c).reshape(self.height, self.width).astype(np.uint16)
     
        return self.depth_img_c



class Somo_Face_Recognition_Node(Node):
    def __init__(self, name):
        super().__init__(name)
        self.declare_parameter("input_h", 480)#480
        self.declare_parameter("input_w", 640)#640

        self.input_h = self.get_parameter('input_h').value
        self.input_w = self.get_parameter('input_w').value

        print("****** Init Compressed2Image Module ******")
        self.compressed2image = Compressed2Image(self.input_w,self.input_h) # -------------------------------------


        # self.four_point_sub = self.create_subscription(String, '/four_point',self.union_callback,10)


        # self.faceboxes_sub=self.create_subscription(FaceBoxes,"/face_match",self.union_callback,1)

        
        self.depth_sub = self.create_subscription(Image,'/camera_up/aligned_depth_to_color/image_raw',self.union_callback,1)  #  four_depth    somo_face_node  /camera_up/aligned_depth_to_color/image_raw/compressed
        # /camera_up/aligned_depth_to_color/image_raw/compressed
        # /camera_up/aligned_depth_to_color/image_raw/compressed
        # /camera_up/aligned_depth_to_color/image_raw/compressedDepth
        # /camera_up/aligned_depth_to_color/image_raw




        
        print('11111111111111111111111111111111111')
        
        self.bridge = CvBridge()
        self.aver_depth = self.create_publisher(Float32, "aver_depth", 10)

    def union_callback(self,msg):
        print('+++++++++++++++++++++++++++++++++++++++')
        print(msg)
        print(type(msg))                # <class 'sensor_msgs.msg._compressed_image.CompressedImage'>
        # print(type())
        print(len(msg.data))
        topic_depth_data=self.compressed2image.forward(msg)


        if  str(type(msg))[-3] == 'e' :
            try :
                print('yyyyyyyyyyyyyyyyyyyy')
                # print()
                # print(len(msg.data))
                # global topic_depth_data
                topic_depth_data=self.compressed2image.forward(msg.data)
                print(topic_depth_data)
            except :
                pass




        try:
            print(len(msg.data))

        #     if len(msg.data) < 41 and len(msg.data) >30 :
        #         global four_point_data
        #         four_point_data = list( np.array(msg.data[1:-1].split(',')).astype("int"))  # 现在是类似[199, 295, 204, 295, 194, 295, 199, 300]的int   列表

        #     if len(msg.data) > 10000 :
        #         # topic_depth_data = msg
        #         # print('深度图')
        #         # print('深度图shape', topic_depth_data.shape)

        #         global topic_depth_data
        #         topic_depth_data=self.compressed2image.forward(msg)

        #         # depth = (topic_depth_data[four_point_data[0]][four_point_data[1]] + topic_depth_data[four_point_data[2]][four_point_data[3]] + topic_depth_data[four_point_data[4]][four_point_data[5]]+ topic_depth_data[four_point_data[6]][four_point_data[7]])/4000
        #         depth = topic_depth_data[0][0] 
                
        #         msg_depth = Float32()
        #         msg_depth.data = depth
        #         self.aver_depth.publish(msg_depth)

        except:
            print('error')
            pass








def main():
    rclpy.init()
    four_point_data = 0
    topic_depth_data = 0
    face_recog_node = Somo_Face_Recognition_Node("four_depth")
    rclpy.spin(face_recog_node)
    face_recog_node.destroy()
    cv2.destroyAllWindows()


if __name__ == '__main__':
    try:
        main()
    except Exception as err:
        print(err)